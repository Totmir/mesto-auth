export default {
  popup: 'popup',
  openedPopup: 'popup_opened',
  avatarPopup: 'popup_type_avatar-updater',
  editProfilePopup: 'popup_type_profile-editor',
  placeAdderPopup: 'popup_type_card-renderer'
}
